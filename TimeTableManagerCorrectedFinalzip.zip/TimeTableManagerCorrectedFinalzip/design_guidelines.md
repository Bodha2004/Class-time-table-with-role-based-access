# Class Timetable Management System - Design Guidelines

## Design Approach
**System-Based Approach**: Material Design principles adapted for educational productivity software. Prioritizes clarity, efficient data display, and role-appropriate interfaces over visual flair.

**Key References**: Google Classroom, Microsoft Teams, Notion (for organizational tools that balance utility with clean aesthetics)

---

## Core Design Principles
1. **Role Clarity**: Each role (Admin/Teacher/Student) has visually distinct dashboard layouts and navigation
2. **Information Hierarchy**: Dense schedule data presented through clear visual structure
3. **Immediate Feedback**: Real-time updates and state changes are immediately visible
4. **Efficient Workflows**: Multi-step processes (creating classes, scheduling) minimized through smart forms

---

## Typography
- **Primary Font**: Inter (via Google Fonts CDN) - excellent for data-dense interfaces
- **Headings**: font-semibold to font-bold, sizes: text-2xl to text-4xl
- **Body Text**: text-base (16px), font-normal, line-height relaxed for readability
- **Data Tables/Schedules**: text-sm (14px), font-medium for labels, font-normal for content
- **Form Labels**: text-sm, font-medium, uppercase tracking-wide for clarity

---

## Layout System
**Spacing Primitives**: Tailwind units of 2, 4, 6, and 8 for consistent rhythm
- Compact spacing: p-2, gap-2 (table cells, tight layouts)
- Standard spacing: p-4, gap-4 (cards, form fields)
- Generous spacing: p-6, gap-6 (sections, page padding)
- Large spacing: p-8, gap-8 (major sections, hero areas)

**Dashboard Structure**:
- Fixed sidebar navigation (w-64) with role-specific menu items
- Main content area with max-w-7xl container
- Sticky header (h-16) with user profile and notifications
- Grid-based timetable view: 7-column layout for weekdays

---

## Component Library

### Navigation
- **Sidebar**: Fixed left navigation with icon + label, role badge at top
- **Top Bar**: User avatar dropdown, notification bell with badge count, quick actions
- **Breadcrumbs**: Show current location in multi-step workflows

### Timetable Display
- **Grid View**: 7-column weekly schedule with time slots as rows
- **Time Slots**: 30-minute or 1-hour blocks, clearly labeled on left axis
- **Class Cards**: Compact cards within grid cells showing class name, room, teacher (for students)
- **Empty Slots**: Subtle background pattern to distinguish from scheduled blocks
- **Current Time Indicator**: Horizontal line marking current time slot

### Forms
- **Admin User Creation**: Two-column layout (left: form fields, right: role preview)
- **Class Scheduling**: Multi-step wizard - (1) Basic info, (2) Time selection, (3) Room assignment
- **Timetable Upload**: Drag-and-drop zone with file format guidelines, preview before import
- **Input Fields**: Full-width with floating labels, clear validation states

### Data Tables
- **User Management Table**: Sortable columns (Name, Role, Status, Actions)
- **Classroom List**: Grid of cards (3-4 columns) showing room details and capacity
- **Class History**: Timeline view for Teachers showing past/upcoming classes
- **Row Actions**: Icon buttons (edit, delete, reschedule) aligned right

### Notifications
- **Toast Notifications**: Top-right corner, 4-second auto-dismiss for success/info
- **Real-time Alert**: Slide-in panel from right for schedule changes (Students)
- **Notification Center**: Dropdown from bell icon with list of recent updates
- **Badges**: Red dot indicator on bell icon when unread notifications exist

### Authentication
- **Login Pages**: Centered card (max-w-md) with role selector at top
- **Admin Login**: Large "Sign in with Google" button with Replit Auth
- **Teacher/Student Login**: Traditional username/password form with clear field labels
- **OTP Input**: 6-digit code entry with auto-focus progression

### Dashboards (Role-Specific)
- **Admin Dashboard**: 3-column stats cards (Total Classes, Active Teachers, Total Students), quick action buttons, recent activity feed
- **Teacher Dashboard**: 2-column layout - left: upcoming classes list, right: quick schedule actions
- **Student Dashboard**: Full-width timetable grid as primary focus, upcoming classes sidebar

### Interactive Elements
- **Buttons**: 
  - Primary actions: Solid background, medium weight
  - Secondary actions: Outlined style
  - Danger actions: Distinct treatment for delete/remove
  - Icon buttons: Circular for compact actions (h-10 w-10)
- **Cards**: Subtle border, minimal shadow, hover state with slight elevation
- **Modals**: Centered overlay (max-w-2xl) for confirmations and complex forms
- **Dropdowns**: Clean list with subtle dividers, hover state on items

---

## Animations
**Minimal Use - Performance First**:
- Page transitions: Fade-in only (200ms)
- Real-time updates: Gentle highlight flash on changed schedule blocks
- Form validation: Shake animation for errors (250ms)
- NO scroll-triggered animations, NO complex hero animations

---

## Images
**No Hero Image**: This is a utility application - launch directly into functional dashboards

**Supporting Imagery**:
1. **Empty States**: Simple illustrations for "No classes scheduled" (placed center of empty timetable grid)
2. **Upload Zone**: Cloud upload icon for timetable import section
3. **User Avatars**: Default avatar icons for users without profile pictures (circular, 40x40px in navigation)
4. **Role Icons**: Admin (shield), Teacher (presentation), Student (graduation cap) used in role badges and selectors

All imagery should be minimal, functional, and never decorative.