#!/usr/bin/env bash
# run_on_ish.sh - helper script for iSH environment (Alpine)
set -e

echo "Checking Node..."
if ! command -v node >/dev/null 2>&1; then
  echo "Node not found. Install with: apk add nodejs npm"
  exit 1
fi

echo "Installing dependencies (root project)..."
npm install

echo "Done. To start the project:"
echo "1) In one shell: cd server && npm run dev"
echo "2) In another shell: cd client && npm run dev"
echo ""
echo "Make sure you have created a .env file in the project root with DATABASE_URL and other env vars."
