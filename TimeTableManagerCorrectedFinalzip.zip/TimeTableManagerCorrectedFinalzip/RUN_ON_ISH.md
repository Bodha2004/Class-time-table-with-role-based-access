# Run TimeTableManager on iPad (VS Code + iSH)

This guide shows how to run **TimeTableManager** inside **iSH (Alpine Linux)** on an iPad and edit via **VS Code (Remote - SSH or code-server)**.  
It avoids installing a local database by using a free remote Postgres (Supabase) which is easiest on iPad.

---

## Overview (high level)
1. Install iSH on your iPad (App Store).  
2. Install required packages (node, npm, git).  
3. Create a free Postgres database using Supabase (or use an existing remote Postgres).  
4. Set environment variables in `.env` file.  
5. Install dependencies and run the server & client.

---

## Prerequisites
- iPad with iSH installed (https://apps.apple.com/app/ish-shell/id1436902243)  
- Optional: VS Code with `Remote - SSH` extension or `code-server` inside iSH for IDE experience.  
- GitHub account (to clone repo) or upload the provided ZIP.

---

## Step-by-step (recommended)

### 1. Create a Supabase (free) project
- Go to https://supabase.com and create a free account.  
- Create a new project and note the **DATABASE URL** (also called `SUPABASE_DB_URL` or `DATABASE_URL`) and DB credentials.  
- Create a new SQL user if necessary. Keep the URL handy.

> Alternatively, you can use any remote Postgres (e.g., ElephantSQL, PlanetScale using Postgres-compatible mode).

### 2. Open iSH and install base packages
Run these commands inside iSH:

```sh
# update
apk update
# install git, node, npm, bash, curl, openssl
apk add git nodejs npm bash curl openssl
# Install build-base if any native modules need compiling
apk add build-base python3
```

> Note: Alpine's `nodejs` package may be an older LTS. If you need a specific Node version, consider using `n` or `corepack` workflows, but this often requires more setup.

### 3. Copy the project into iSH
- If you have the ZIP on the iPad, move it into iSH's accessible directory (e.g., `/root`) or clone from GitHub:
```sh
git clone <your-repo-or-uploaded-repo-url>
cd TimeTableManager
```

### 4. Create `.env` file
In the project root create a `.env` file with these variables:

```
# Example .env
DATABASE_URL=postgresql://USER:PASSWORD@HOST:PORT/DATABASE
REPL_ID=your-repl-id-if-using-replit-auth
ISSUER_URL=https://replit.com/oidc
SESSION_SECRET=some_random_secret
PORT=3000
CLIENT_PORT=5173
# any other env variables used by your project
```

Replace `DATABASE_URL` with your Supabase connection string. Keep this file secret.

### 5. Install dependencies
```sh
# recommended to use npm here
npm install
# or if you prefer pnpm/yarn (install them first)
```

### 6. Run database migrations
This project uses Drizzle/SQL migrations. If the repo includes migrations, run them. If not, you'll need to create the schema in Supabase using the SQL provided in repository or run the server which may auto-create tables.

If migrations exist:
```sh
# example (adjust to your project's migration command)
npx drizzle-kit migrate:deploy
```

If not, open Supabase SQL editor and run the schema SQL found in `server` or `shared` folders (look for `.sql` or schema files).

### 7. Start the server and client
Open two shells (or use `tmux` inside iSH):

Server:
```sh
# from project root
cd server
npm run dev
```

Client:
```sh
cd client
npm run dev
```

By default Vite (client) will be on port 5173 and server on port 3000. If you need external access, use `ngrok` or `localtunnel` (install via npm).

### 8. Access UI from Safari (same iPad)
If both client & server are running inside iSH, you can open `http://localhost:5173` in Safari (depending on networking between iSH and iPad; if that doesn't work, consider running `code-server` and using its built-in preview, or use tunneling).

---

## Troubleshooting & Tips
- If native modules fail to build, install `build-base` and `python3` (done above).
- If Node version mismatch, consider running the client using `npm run build` on another machine and serve static files via server.
- If you cannot run Postgres locally, always use Supabase remote DB — easiest solution on iPad.
- Use VS Code on desktop to run migrations if iSH fails to run them.

---

## Quick run script
A helper script `run_on_ish.sh` is included which:
- checks for node
- installs dependencies (if needed)
- prints next steps to start server & client

Run it with:
```sh
bash run_on_ish.sh
```

---

If you want, I can also:
- add a `docker-compose` setup (not recommended for iSH)  
- prepare an export SQL to seed admin/teacher/student users for testing  
- create an example `.env.example` with placeholder values

Tell me which of these extra things you want; otherwise use the included script and steps above.