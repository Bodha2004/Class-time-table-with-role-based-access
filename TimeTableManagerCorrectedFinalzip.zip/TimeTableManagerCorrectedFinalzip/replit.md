# Class Timetable Management System

## Overview

A comprehensive web-based timetable management system for educational institutions that enables administrators, teachers, and students to manage class schedules, classrooms, and subjects. The system provides role-based dashboards with real-time notifications and an interactive timetable grid view for visualizing weekly schedules.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React with TypeScript for type-safe component development
- Vite as the build tool and development server for fast refresh and optimized production builds
- Wouter for lightweight client-side routing
- Path aliases configured for clean imports (`@/`, `@shared/`, `@assets/`)

**UI Component Strategy**
- Shadcn/ui component library (New York style) for consistent, accessible UI primitives
- Radix UI primitives as the foundation for complex interactive components
- Tailwind CSS for utility-first styling with custom design tokens
- Class Variance Authority (CVA) for component variant management

**State Management**
- TanStack Query (React Query) for server state, caching, and data synchronization
- Custom hooks pattern for authentication state (`useAuth`) and theme management (`useTheme`)
- React Hook Form with Zod validation for form state and validation

**Design System**
- Material Design-inspired approach prioritizing clarity and data density
- Custom color system with support for light/dark themes via CSS variables
- Spacing primitives based on Tailwind units (2, 4, 6, 8) for consistent rhythm
- Inter font family for optimal readability in data-dense interfaces

### Backend Architecture

**Server Framework**
- Express.js with TypeScript for the REST API
- HTTP server with WebSocket support for real-time notifications
- Session-based authentication using express-session with PostgreSQL storage

**Authentication System**
- Dual authentication strategy:
  - OAuth/OIDC via Replit Auth for admin users
  - Username/password with bcrypt hashing for teachers and students
- Passport.js for authentication middleware
- Role-based access control (admin, teacher, student) enforced at route level

**API Design**
- RESTful endpoints organized by resource type (users, classrooms, classes, subjects, schedules, notifications)
- Role-specific endpoints (e.g., `/api/admin/stats`, `/api/teacher/stats`, `/api/student/stats`)
- Middleware for authentication checks (`isAuthenticated`, `isAdmin`, `isTeacherOrAdmin`)

**Real-time Communication**
- WebSocket server for broadcasting schedule changes to connected clients
- Class-specific subscription channels for targeted notifications
- Client reconnection handling with subscription restoration

### Data Storage

**Database Solution**
- PostgreSQL via Neon serverless driver
- Drizzle ORM for type-safe database queries and schema management
- Schema-first approach with Zod integration for runtime validation

**Schema Design**
- **Users table**: Supports both OAuth and password-based authentication with role enum
- **Classrooms table**: Physical/virtual room management with capacity tracking
- **Classes table**: Student groups/sections with grade level
- **Subjects table**: Course definitions with color coding for visual distinction
- **Schedules table**: Junction table linking classes, subjects, teachers, classrooms, and time slots
- **Notifications table**: User-specific notifications with read status and metadata
- **Sessions table**: Server-side session storage for authentication

**Relationships**
- One-to-many: Teacher to schedules, classroom to schedules, class to schedules
- Many-to-one with details: Schedules include denormalized data for efficient querying

### External Dependencies

**Database & Infrastructure**
- **Neon PostgreSQL**: Serverless PostgreSQL database with WebSocket support for connection pooling
- **connect-pg-simple**: PostgreSQL session store for express-session

**Authentication & Security**
- **Passport.js**: Authentication middleware framework
- **passport-local**: Local username/password strategy
- **openid-client**: OIDC/OAuth client for Replit authentication
- **bcryptjs**: Password hashing library
- **memoizee**: Response caching for OIDC configuration

**UI Component Libraries**
- **Radix UI**: Headless UI primitives for accessible components (22+ component packages)
- **Lucide React**: Icon library for consistent iconography
- **cmdk**: Command palette component
- **date-fns**: Date manipulation and formatting
- **react-day-picker**: Calendar component for date selection
- **vaul**: Drawer/bottom sheet component
- **recharts**: Charting library for data visualization

**Development Tools**
- **Replit Vite Plugins**: Runtime error overlay, cartographer for code navigation, dev banner
- **drizzle-kit**: Database migration tool
- **ESBuild**: Server bundler for production builds
- **PostCSS & Autoprefixer**: CSS processing

**Form & Validation**
- **React Hook Form**: Form state management
- **@hookform/resolvers**: Validation resolver adapters
- **Zod**: Schema validation library
- **drizzle-zod**: Drizzle schema to Zod conversion

**Type Safety**
- TypeScript with strict mode enabled
- Shared schema definitions between client and server
- Runtime validation aligned with TypeScript types via Zod