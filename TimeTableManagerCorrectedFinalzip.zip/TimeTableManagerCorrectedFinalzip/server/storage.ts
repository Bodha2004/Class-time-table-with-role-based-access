import {
  users,
  classrooms,
  classes,
  subjects,
  schedules,
  notifications,
  type User,
  type UpsertUser,
  type InsertUser,
  type Classroom,
  type InsertClassroom,
  type Class,
  type InsertClass,
  type Subject,
  type InsertSubject,
  type Schedule,
  type InsertSchedule,
  type ScheduleWithDetails,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  createUserWithPassword(user: InsertUser & { password: string }): Promise<User>;
  getUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  deleteUser(id: string): Promise<void>;
  validateUserCredentials(username: string, password: string, role: string): Promise<User | null>;
  
  // Classroom operations
  getClassrooms(): Promise<Classroom[]>;
  getClassroom(id: string): Promise<Classroom | undefined>;
  createClassroom(classroom: InsertClassroom): Promise<Classroom>;
  updateClassroom(id: string, classroom: Partial<InsertClassroom>): Promise<Classroom>;
  deleteClassroom(id: string): Promise<void>;
  
  // Class operations
  getClasses(): Promise<Class[]>;
  getClass(id: string): Promise<Class | undefined>;
  createClass(cls: InsertClass): Promise<Class>;
  updateClass(id: string, cls: Partial<InsertClass>): Promise<Class>;
  deleteClass(id: string): Promise<void>;
  
  // Subject operations
  getSubjects(): Promise<Subject[]>;
  getSubject(id: string): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  updateSubject(id: string, subject: Partial<InsertSubject>): Promise<Subject>;
  deleteSubject(id: string): Promise<void>;
  
  // Schedule operations
  getSchedules(): Promise<ScheduleWithDetails[]>;
  getSchedulesByClass(classId: string): Promise<ScheduleWithDetails[]>;
  getSchedulesByTeacher(teacherId: string): Promise<ScheduleWithDetails[]>;
  getSchedule(id: string): Promise<ScheduleWithDetails | undefined>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: string, schedule: Partial<InsertSchedule>): Promise<Schedule>;
  deleteSchedule(id: string): Promise<void>;
  
  // Notification operations
  getNotifications(classId?: string): Promise<Notification[]>;
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: string): Promise<void>;
  markAllNotificationsAsRead(classId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({ ...userData, role: userData.role || "admin" })
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async createUserWithPassword(userData: InsertUser & { password: string }): Promise<User> {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        password: hashedPassword,
      })
      .returning();
    return user;
  }

  async getUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return db.select().from(users).where(eq(users.role, role as any)).orderBy(desc(users.createdAt));
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async validateUserCredentials(username: string, password: string, role: string): Promise<User | null> {
    const [user] = await db
      .select()
      .from(users)
      .where(and(eq(users.username, username), eq(users.role, role as any)));
    
    if (!user || !user.password) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  // Classroom operations
  async getClassrooms(): Promise<Classroom[]> {
    return db.select().from(classrooms).orderBy(classrooms.name);
  }

  async getClassroom(id: string): Promise<Classroom | undefined> {
    const [classroom] = await db.select().from(classrooms).where(eq(classrooms.id, id));
    return classroom;
  }

  async createClassroom(classroom: InsertClassroom): Promise<Classroom> {
    const [created] = await db.insert(classrooms).values(classroom).returning();
    return created;
  }

  async updateClassroom(id: string, classroom: Partial<InsertClassroom>): Promise<Classroom> {
    const [updated] = await db
      .update(classrooms)
      .set({ ...classroom, updatedAt: new Date() })
      .where(eq(classrooms.id, id))
      .returning();
    return updated;
  }

  async deleteClassroom(id: string): Promise<void> {
    await db.delete(classrooms).where(eq(classrooms.id, id));
  }

  // Class operations
  async getClasses(): Promise<Class[]> {
    return db.select().from(classes).orderBy(classes.name);
  }

  async getClass(id: string): Promise<Class | undefined> {
    const [cls] = await db.select().from(classes).where(eq(classes.id, id));
    return cls;
  }

  async createClass(cls: InsertClass): Promise<Class> {
    const [created] = await db.insert(classes).values(cls).returning();
    return created;
  }

  async updateClass(id: string, cls: Partial<InsertClass>): Promise<Class> {
    const [updated] = await db
      .update(classes)
      .set({ ...cls, updatedAt: new Date() })
      .where(eq(classes.id, id))
      .returning();
    return updated;
  }

  async deleteClass(id: string): Promise<void> {
    await db.delete(classes).where(eq(classes.id, id));
  }

  // Subject operations
  async getSubjects(): Promise<Subject[]> {
    return db.select().from(subjects).orderBy(subjects.name);
  }

  async getSubject(id: string): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject;
  }

  async createSubject(subject: InsertSubject): Promise<Subject> {
    const [created] = await db.insert(subjects).values(subject).returning();
    return created;
  }

  async updateSubject(id: string, subject: Partial<InsertSubject>): Promise<Subject> {
    const [updated] = await db
      .update(subjects)
      .set(subject)
      .where(eq(subjects.id, id))
      .returning();
    return updated;
  }

  async deleteSubject(id: string): Promise<void> {
    await db.delete(subjects).where(eq(subjects.id, id));
  }

  // Schedule operations
  async getSchedules(): Promise<ScheduleWithDetails[]> {
    const result = await db
      .select({
        schedule: schedules,
        subject: subjects,
        teacher: users,
        classroom: classrooms,
        class: classes,
      })
      .from(schedules)
      .leftJoin(subjects, eq(schedules.subjectId, subjects.id))
      .leftJoin(users, eq(schedules.teacherId, users.id))
      .leftJoin(classrooms, eq(schedules.classroomId, classrooms.id))
      .leftJoin(classes, eq(schedules.classId, classes.id))
      .orderBy(schedules.dayOfWeek, schedules.startTime);

    return result.map((row) => ({
      ...row.schedule,
      subject: row.subject!,
      teacher: row.teacher!,
      classroom: row.classroom!,
      class: row.class!,
    }));
  }

  async getSchedulesByClass(classId: string): Promise<ScheduleWithDetails[]> {
    const result = await db
      .select({
        schedule: schedules,
        subject: subjects,
        teacher: users,
        classroom: classrooms,
        class: classes,
      })
      .from(schedules)
      .leftJoin(subjects, eq(schedules.subjectId, subjects.id))
      .leftJoin(users, eq(schedules.teacherId, users.id))
      .leftJoin(classrooms, eq(schedules.classroomId, classrooms.id))
      .leftJoin(classes, eq(schedules.classId, classes.id))
      .where(eq(schedules.classId, classId))
      .orderBy(schedules.dayOfWeek, schedules.startTime);

    return result.map((row) => ({
      ...row.schedule,
      subject: row.subject!,
      teacher: row.teacher!,
      classroom: row.classroom!,
      class: row.class!,
    }));
  }

  async getSchedulesByTeacher(teacherId: string): Promise<ScheduleWithDetails[]> {
    const result = await db
      .select({
        schedule: schedules,
        subject: subjects,
        teacher: users,
        classroom: classrooms,
        class: classes,
      })
      .from(schedules)
      .leftJoin(subjects, eq(schedules.subjectId, subjects.id))
      .leftJoin(users, eq(schedules.teacherId, users.id))
      .leftJoin(classrooms, eq(schedules.classroomId, classrooms.id))
      .leftJoin(classes, eq(schedules.classId, classes.id))
      .where(eq(schedules.teacherId, teacherId))
      .orderBy(schedules.dayOfWeek, schedules.startTime);

    return result.map((row) => ({
      ...row.schedule,
      subject: row.subject!,
      teacher: row.teacher!,
      classroom: row.classroom!,
      class: row.class!,
    }));
  }

  async getSchedule(id: string): Promise<ScheduleWithDetails | undefined> {
    const result = await db
      .select({
        schedule: schedules,
        subject: subjects,
        teacher: users,
        classroom: classrooms,
        class: classes,
      })
      .from(schedules)
      .leftJoin(subjects, eq(schedules.subjectId, subjects.id))
      .leftJoin(users, eq(schedules.teacherId, users.id))
      .leftJoin(classrooms, eq(schedules.classroomId, classrooms.id))
      .leftJoin(classes, eq(schedules.classId, classes.id))
      .where(eq(schedules.id, id));

    if (result.length === 0) return undefined;

    const row = result[0];
    return {
      ...row.schedule,
      subject: row.subject!,
      teacher: row.teacher!,
      classroom: row.classroom!,
      class: row.class!,
    };
  }

  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    const [created] = await db.insert(schedules).values(schedule).returning();
    return created;
  }

  async updateSchedule(id: string, schedule: Partial<InsertSchedule>): Promise<Schedule> {
    const [updated] = await db
      .update(schedules)
      .set({ ...schedule, updatedAt: new Date() })
      .where(eq(schedules.id, id))
      .returning();
    return updated;
  }

  async deleteSchedule(id: string): Promise<void> {
    await db.delete(schedules).where(eq(schedules.id, id));
  }

  // Notification operations
  async getNotifications(classId?: string): Promise<Notification[]> {
    if (classId) {
      return db
        .select()
        .from(notifications)
        .where(eq(notifications.classId, classId))
        .orderBy(desc(notifications.createdAt));
    }
    return db.select().from(notifications).orderBy(desc(notifications.createdAt));
  }

  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    // Get user's classId first
    const user = await this.getUser(userId);
    if (!user?.classId) return [];

    return db
      .select()
      .from(notifications)
      .where(eq(notifications.classId, user.classId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(notification).returning();
    return created;
  }

  async markNotificationAsRead(id: string): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }

  async markAllNotificationsAsRead(classId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.classId, classId));
  }
}

export const storage = new DatabaseStorage();
