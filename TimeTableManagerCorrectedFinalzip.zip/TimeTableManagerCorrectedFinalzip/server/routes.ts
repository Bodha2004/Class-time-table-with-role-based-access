import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, isAdmin, isTeacherOrAdmin } from "./replitAuth";
import {
  insertClassroomSchema,
  insertClassSchema,
  insertSubjectSchema,
  insertScheduleSchema,
  createUserAccountSchema,
  loginSchema,
} from "@shared/schema";

// Store connected WebSocket clients by class ID
const classClients = new Map<string, Set<WebSocket>>();

function broadcastToClass(classId: string, message: object) {
  const clients = classClients.get(classId);
  if (clients) {
    const payload = JSON.stringify(message);
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // WebSocket server for real-time notifications
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws, req) => {
    let userClassId: string | null = null;

    ws.on("message", (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === "subscribe" && message.classId) {
          userClassId = message.classId;
          if (!classClients.has(userClassId)) {
            classClients.set(userClassId, new Set());
          }
          classClients.get(userClassId)?.add(ws);
        }
      } catch (e) {
        console.error("WebSocket message parse error:", e);
      }
    });

    ws.on("close", () => {
      if (userClassId) {
        classClients.get(userClassId)?.delete(ws);
      }
    });
  });

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Don't send password to client
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Username/password login for teachers and students
  app.post("/api/auth/login", async (req, res) => {
    try {
      const parsed = loginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid input" });
      }

      const { username, password } = parsed.data;
      const role = req.body.role || "student";

      const user = await storage.validateUserCredentials(username, password, role);
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Create session for username/password user
      (req as any).login(
        { id: user.id, role: user.role, username: user.username },
        (err: any) => {
          if (err) {
            console.error("Login error:", err);
            return res.status(500).json({ message: "Login failed" });
          }
          const { password, ...userWithoutPassword } = user;
          res.json(userWithoutPassword);
        }
      );
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Admin stats
  app.get("/api/admin/stats", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const allUsers = await storage.getUsers();
      const teachers = allUsers.filter((u) => u.role === "teacher");
      const students = allUsers.filter((u) => u.role === "student");
      const classrooms = await storage.getClassrooms();
      const classes = await storage.getClasses();
      const schedules = await storage.getSchedules();

      res.json({
        totalTeachers: teachers.length,
        totalStudents: students.length,
        totalClassrooms: classrooms.length,
        totalClasses: classes.length,
        totalSchedules: schedules.length,
        recentUsers: allUsers
          .filter((u) => u.role !== "admin")
          .slice(0, 10),
      });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Teacher stats
  app.get("/api/teacher/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const schedules = await storage.getSchedulesByTeacher(userId);
      
      const today = new Date().toLocaleDateString("en-US", { weekday: "long" }).toLowerCase();
      const todayClasses = schedules.filter((s) => s.dayOfWeek === today);

      res.json({
        totalSchedules: schedules.length,
        todayClasses: todayClasses.length,
        upcomingClasses: schedules,
      });
    } catch (error) {
      console.error("Error fetching teacher stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Student stats
  app.get("/api/student/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user?.classId) {
        return res.json({
          todayClasses: 0,
          weeklyClasses: 0,
          unreadNotifications: 0,
          upcomingClasses: [],
          recentNotifications: [],
        });
      }

      const schedules = await storage.getSchedulesByClass(user.classId);
      const notifications = await storage.getNotificationsByUser(userId);
      
      const today = new Date().toLocaleDateString("en-US", { weekday: "long" }).toLowerCase();
      const todayClasses = schedules.filter((s) => s.dayOfWeek === today);
      const unreadNotifications = notifications.filter((n) => !n.isRead);

      res.json({
        todayClasses: todayClasses.length,
        weeklyClasses: schedules.length,
        unreadNotifications: unreadNotifications.length,
        upcomingClasses: schedules,
        recentNotifications: notifications.slice(0, 10),
      });
    } catch (error) {
      console.error("Error fetching student stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // User routes
  app.get("/api/users", isAuthenticated, async (req, res) => {
    try {
      const role = req.query.role as string | undefined;
      const users = role
        ? await storage.getUsersByRole(role)
        : await storage.getUsers();
      
      // Don't send passwords to client
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/users", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parsed = createUserAccountSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      // Check if username already exists
      const existing = await storage.getUserByUsername(parsed.data.username);
      if (existing) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUserWithPassword({
        username: parsed.data.username,
        password: parsed.data.password,
        firstName: parsed.data.firstName || null,
        lastName: parsed.data.lastName || null,
        email: parsed.data.email || null,
        role: parsed.data.role,
        classId: parsed.data.classId || null,
      });

      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.delete("/api/users/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Classroom routes
  app.get("/api/classrooms", isAuthenticated, async (req, res) => {
    try {
      const classrooms = await storage.getClassrooms();
      res.json(classrooms);
    } catch (error) {
      console.error("Error fetching classrooms:", error);
      res.status(500).json({ message: "Failed to fetch classrooms" });
    }
  });

  app.post("/api/classrooms", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parsed = insertClassroomSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      const classroom = await storage.createClassroom(parsed.data);
      res.status(201).json(classroom);
    } catch (error) {
      console.error("Error creating classroom:", error);
      res.status(500).json({ message: "Failed to create classroom" });
    }
  });

  app.patch("/api/classrooms/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parsed = insertClassroomSchema.partial().safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      const classroom = await storage.updateClassroom(req.params.id, parsed.data);
      res.json(classroom);
    } catch (error) {
      console.error("Error updating classroom:", error);
      res.status(500).json({ message: "Failed to update classroom" });
    }
  });

  app.delete("/api/classrooms/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.deleteClassroom(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting classroom:", error);
      res.status(500).json({ message: "Failed to delete classroom" });
    }
  });

  // Class routes
  app.get("/api/classes", isAuthenticated, async (req, res) => {
    try {
      const classes = await storage.getClasses();
      res.json(classes);
    } catch (error) {
      console.error("Error fetching classes:", error);
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  app.post("/api/classes", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parsed = insertClassSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      const cls = await storage.createClass(parsed.data);
      res.status(201).json(cls);
    } catch (error) {
      console.error("Error creating class:", error);
      res.status(500).json({ message: "Failed to create class" });
    }
  });

  app.patch("/api/classes/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parsed = insertClassSchema.partial().safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      const cls = await storage.updateClass(req.params.id, parsed.data);
      res.json(cls);
    } catch (error) {
      console.error("Error updating class:", error);
      res.status(500).json({ message: "Failed to update class" });
    }
  });

  app.delete("/api/classes/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.deleteClass(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting class:", error);
      res.status(500).json({ message: "Failed to delete class" });
    }
  });

  // Subject routes
  app.get("/api/subjects", isAuthenticated, async (req, res) => {
    try {
      const subjects = await storage.getSubjects();
      res.json(subjects);
    } catch (error) {
      console.error("Error fetching subjects:", error);
      res.status(500).json({ message: "Failed to fetch subjects" });
    }
  });

  app.post("/api/subjects", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parsed = insertSubjectSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      const subject = await storage.createSubject(parsed.data);
      res.status(201).json(subject);
    } catch (error) {
      console.error("Error creating subject:", error);
      res.status(500).json({ message: "Failed to create subject" });
    }
  });

  app.patch("/api/subjects/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parsed = insertSubjectSchema.partial().safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      const subject = await storage.updateSubject(req.params.id, parsed.data);
      res.json(subject);
    } catch (error) {
      console.error("Error updating subject:", error);
      res.status(500).json({ message: "Failed to update subject" });
    }
  });

  app.delete("/api/subjects/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.deleteSubject(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting subject:", error);
      res.status(500).json({ message: "Failed to delete subject" });
    }
  });

  // Schedule routes
  app.get("/api/schedules", isAuthenticated, async (req: any, res) => {
    try {
      const classId = req.query.classId as string | undefined;
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);

      let schedules;
      if (classId) {
        schedules = await storage.getSchedulesByClass(classId);
      } else if (user?.role === "teacher") {
        schedules = await storage.getSchedulesByTeacher(userId);
      } else if (user?.role === "student" && user.classId) {
        schedules = await storage.getSchedulesByClass(user.classId);
      } else {
        schedules = await storage.getSchedules();
      }

      res.json(schedules);
    } catch (error) {
      console.error("Error fetching schedules:", error);
      res.status(500).json({ message: "Failed to fetch schedules" });
    }
  });

  app.post("/api/schedules", isAuthenticated, isTeacherOrAdmin, async (req: any, res) => {
    try {
      const parsed = insertScheduleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      // For teachers, use their own ID
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);
      
      let scheduleData = parsed.data;
      if (user?.role === "teacher") {
        scheduleData = { ...scheduleData, teacherId: userId };
      }

      const schedule = await storage.createSchedule(scheduleData);

      // Get full schedule details for notification
      const fullSchedule = await storage.getSchedule(schedule.id);

      // Create notification for students
      if (fullSchedule) {
        const notification = await storage.createNotification({
          type: "schedule_added",
          title: "New Class Scheduled",
          message: `${fullSchedule.subject?.name} has been scheduled for ${fullSchedule.dayOfWeek} at ${fullSchedule.startTime?.slice(0, 5)} in ${fullSchedule.classroom?.name}`,
          scheduleId: schedule.id,
          classId: schedule.classId,
        });

        // Broadcast to connected students
        broadcastToClass(schedule.classId, {
          type: "notification",
          data: notification,
        });
      }

      res.status(201).json(schedule);
    } catch (error) {
      console.error("Error creating schedule:", error);
      res.status(500).json({ message: "Failed to create schedule" });
    }
  });

  app.patch("/api/schedules/:id", isAuthenticated, isTeacherOrAdmin, async (req: any, res) => {
    try {
      const parsed = insertScheduleSchema.partial().safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.message });
      }

      const existingSchedule = await storage.getSchedule(req.params.id);
      if (!existingSchedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }

      // Check if teacher owns this schedule
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);
      if (user?.role === "teacher" && existingSchedule.teacherId !== userId) {
        return res.status(403).json({ message: "You can only edit your own schedules" });
      }

      const schedule = await storage.updateSchedule(req.params.id, parsed.data);
      const fullSchedule = await storage.getSchedule(schedule.id);

      // Create notification for students
      if (fullSchedule) {
        const notification = await storage.createNotification({
          type: "schedule_updated",
          title: "Class Schedule Updated",
          message: `${fullSchedule.subject?.name} schedule has been updated. Now at ${fullSchedule.dayOfWeek} ${fullSchedule.startTime?.slice(0, 5)} in ${fullSchedule.classroom?.name}`,
          scheduleId: schedule.id,
          classId: schedule.classId,
        });

        broadcastToClass(schedule.classId, {
          type: "notification",
          data: notification,
        });
      }

      res.json(schedule);
    } catch (error) {
      console.error("Error updating schedule:", error);
      res.status(500).json({ message: "Failed to update schedule" });
    }
  });

  app.delete("/api/schedules/:id", isAuthenticated, isTeacherOrAdmin, async (req: any, res) => {
    try {
      const existingSchedule = await storage.getSchedule(req.params.id);
      if (!existingSchedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }

      // Check if teacher owns this schedule
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);
      if (user?.role === "teacher" && existingSchedule.teacherId !== userId) {
        return res.status(403).json({ message: "You can only delete your own schedules" });
      }

      // Create notification before deleting
      const notification = await storage.createNotification({
        type: "schedule_deleted",
        title: "Class Cancelled",
        message: `${existingSchedule.subject?.name} on ${existingSchedule.dayOfWeek} at ${existingSchedule.startTime?.slice(0, 5)} has been cancelled`,
        scheduleId: null,
        classId: existingSchedule.classId,
      });

      broadcastToClass(existingSchedule.classId, {
        type: "notification",
        data: notification,
      });

      await storage.deleteSchedule(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting schedule:", error);
      res.status(500).json({ message: "Failed to delete schedule" });
    }
  });

  // Notification routes
  app.get("/api/notifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const notifications = await storage.getNotificationsByUser(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    try {
      await storage.markNotificationAsRead(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.post("/api/notifications/mark-all-read", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const user = await storage.getUser(userId);
      
      if (user?.classId) {
        await storage.markAllNotificationsAsRead(user.classId);
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark notifications as read" });
    }
  });

  return httpServer;
}
