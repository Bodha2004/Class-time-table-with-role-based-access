import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ThemeToggle } from "@/components/ThemeToggle";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { NotificationBell } from "@/components/NotificationBell";
import { useAuth } from "@/hooks/useAuth";
import { FullPageLoader } from "@/components/LoadingSpinner";
import { useQuery } from "@tanstack/react-query";

// Pages
import Landing from "@/pages/Landing";
import Login from "@/pages/Login";
import NotFound from "@/pages/not-found";
import AdminDashboard from "@/pages/AdminDashboard";
import TeacherDashboard from "@/pages/TeacherDashboard";
import StudentDashboard from "@/pages/StudentDashboard";
import UsersPage from "@/pages/UsersPage";
import ClassroomsPage from "@/pages/ClassroomsPage";
import ClassesPage from "@/pages/ClassesPage";
import SubjectsPage from "@/pages/SubjectsPage";
import SchedulesPage from "@/pages/SchedulesPage";
import TimetablePage from "@/pages/TimetablePage";
import NotificationsPage from "@/pages/NotificationsPage";

import type { Notification } from "@shared/schema";

function DashboardByRole() {
  const { user } = useAuth();
  
  if (user?.role === "admin") {
    return <AdminDashboard />;
  } else if (user?.role === "teacher") {
    return <TeacherDashboard />;
  } else {
    return <StudentDashboard />;
  }
}

function AuthenticatedApp() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const isStudent = user?.role === "student";

  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: isStudent,
  });

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex min-h-screen w-full">
        <AppSidebar user={user} />
        <div className="flex flex-col flex-1 w-full">
          {/* Header */}
          <header className="sticky top-0 z-40 flex items-center justify-between h-16 px-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-2">
              {isStudent && (
                <NotificationBell
                  notifications={notifications}
                />
              )}
              <ThemeToggle />
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 p-6 overflow-auto">
            <div className="max-w-7xl mx-auto">
              <Switch>
                <Route path="/" component={DashboardByRole} />
                {isAdmin && (
                  <>
                    <Route path="/users" component={UsersPage} />
                    <Route path="/classrooms" component={ClassroomsPage} />
                    <Route path="/classes" component={ClassesPage} />
                    <Route path="/subjects" component={SubjectsPage} />
                    <Route path="/schedules" component={SchedulesPage} />
                  </>
                )}
                {!isStudent && (
                  <>
                    <Route path="/schedules" component={SchedulesPage} />
                    <Route path="/timetable" component={TimetablePage} />
                  </>
                )}
                {isStudent && (
                  <>
                    <Route path="/timetable" component={TimetablePage} />
                    <Route path="/notifications" component={NotificationsPage} />
                  </>
                )}
                <Route component={NotFound} />
              </Switch>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <FullPageLoader text="Loading..." />;
  }

  if (!isAuthenticated) {
    return (
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/login" component={Login} />
        <Route component={Landing} />
      </Switch>
    );
  }

  return <AuthenticatedApp />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
