import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  Clock,
  Calendar,
  MapPin,
  Bell,
  ChevronRight,
  User,
  BookOpen,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatsCard } from "@/components/StatsCard";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { EmptyState } from "@/components/EmptyState";
import { TimetableGrid } from "@/components/TimetableGrid";
import { format } from "date-fns";
import type { ScheduleWithDetails, Notification } from "@shared/schema";

interface StudentStats {
  todayClasses: number;
  weeklyClasses: number;
  unreadNotifications: number;
  upcomingClasses: ScheduleWithDetails[];
  recentNotifications: Notification[];
}

export default function StudentDashboard() {
  const { data: stats, isLoading } = useQuery<StudentStats>({
    queryKey: ["/api/student/stats"],
  });

  const today = new Date().toLocaleDateString("en-US", { weekday: "long" }).toLowerCase();
  const currentTime = format(new Date(), "HH:mm");

  const todaysClasses = stats?.upcomingClasses?.filter(
    (s) => s.dayOfWeek === today
  ) || [];

  const sortedTodaysClasses = [...todaysClasses].sort((a, b) => {
    return (a.startTime || "").localeCompare(b.startTime || "");
  });

  const nextClass = sortedTodaysClasses.find(
    (s) => s.startTime && s.startTime > currentTime
  );

  if (isLoading) {
    return <LoadingSpinner text="Loading your dashboard..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Dashboard</h1>
          <p className="text-muted-foreground">
            View your class schedule and notifications
          </p>
        </div>
        <Link href="/notifications">
          <Button variant="outline" className="gap-2" data-testid="button-view-notifications">
            <Bell className="h-4 w-4" />
            Notifications
            {stats?.unreadNotifications ? (
              <Badge variant="destructive" className="ml-1">
                {stats.unreadNotifications}
              </Badge>
            ) : null}
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        <StatsCard
          title="Today's Classes"
          value={stats?.todayClasses || 0}
          icon={Calendar}
          color="primary"
          description="Classes scheduled for today"
        />
        <StatsCard
          title="Weekly Classes"
          value={stats?.weeklyClasses || 0}
          icon={Clock}
          color="chart-2"
          description="Total classes this week"
        />
        <StatsCard
          title="Notifications"
          value={stats?.unreadNotifications || 0}
          icon={Bell}
          color="chart-4"
          description="Unread updates"
        />
      </div>

      {/* Next Class Highlight */}
      {nextClass && (
        <Card className="border-primary/50 bg-primary/5">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 text-primary mb-4">
              <Clock className="h-5 w-5" />
              <span className="font-semibold">Next Class</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div
                  className="w-2 h-16 rounded-full"
                  style={{ backgroundColor: nextClass.subject?.color || "#3B82F6" }}
                />
                <div>
                  <h3 className="text-xl font-bold">{nextClass.subject?.name}</h3>
                  <div className="flex flex-wrap items-center gap-3 mt-1 text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {nextClass.startTime?.slice(0, 5)} - {nextClass.endTime?.slice(0, 5)}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {nextClass.classroom?.name}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="h-4 w-4" />
                      {nextClass.teacher?.firstName} {nextClass.teacher?.lastName}
                    </span>
                  </div>
                </div>
              </div>
              <Link href="/timetable">
                <Button data-testid="button-view-full-timetable">
                  View Full Timetable
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Today's Schedule */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Today's Schedule
          </CardTitle>
          <Badge variant="outline">
            {format(new Date(), "EEEE, MMMM d")}
          </Badge>
        </CardHeader>
        <CardContent>
          {sortedTodaysClasses.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="No classes today"
              description="You don't have any classes scheduled for today. Enjoy your day!"
            />
          ) : (
            <div className="space-y-3">
              {sortedTodaysClasses.map((schedule) => {
                const isPast = schedule.endTime && schedule.endTime < currentTime;
                const isCurrent =
                  schedule.startTime &&
                  schedule.endTime &&
                  schedule.startTime <= currentTime &&
                  schedule.endTime >= currentTime;

                return (
                  <div
                    key={schedule.id}
                    className={`flex items-center gap-4 p-4 rounded-lg border ${
                      isCurrent
                        ? "border-primary bg-primary/5"
                        : isPast
                        ? "opacity-60"
                        : ""
                    }`}
                    data-testid={`schedule-item-${schedule.id}`}
                  >
                    {/* Time Block */}
                    <div className="text-center min-w-[80px]">
                      <p className="text-lg font-bold">
                        {schedule.startTime?.slice(0, 5)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        to {schedule.endTime?.slice(0, 5)}
                      </p>
                    </div>

                    {/* Divider */}
                    <div
                      className="w-1 h-12 rounded-full"
                      style={{ backgroundColor: schedule.subject?.color || "#3B82F6" }}
                    />

                    {/* Class Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold">{schedule.subject?.name}</p>
                        {isCurrent && (
                          <Badge variant="default" className="text-xs">
                            In Progress
                          </Badge>
                        )}
                        {isPast && (
                          <Badge variant="secondary" className="text-xs">
                            Completed
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {schedule.classroom?.name}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {schedule.teacher?.firstName} {schedule.teacher?.lastName}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Notifications */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Recent Updates
          </CardTitle>
          <Link href="/notifications">
            <Button variant="ghost" size="sm" className="gap-1" data-testid="button-all-notifications">
              View All
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {!stats?.recentNotifications || stats.recentNotifications.length === 0 ? (
            <EmptyState
              icon={Bell}
              title="No notifications"
              description="You're all caught up! New schedule updates will appear here."
            />
          ) : (
            <div className="space-y-3">
              {stats.recentNotifications.slice(0, 5).map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 rounded-lg border ${
                    !notification.isRead ? "bg-primary/5 border-primary/20" : ""
                  }`}
                  data-testid={`notification-${notification.id}`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-2 h-2 rounded-full mt-2 ${
                        !notification.isRead ? "bg-primary" : "bg-muted"
                      }`}
                    />
                    <div>
                      <p className="font-medium text-sm">{notification.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {notification.message}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
