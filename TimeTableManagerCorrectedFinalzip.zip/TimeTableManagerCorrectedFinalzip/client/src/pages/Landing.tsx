import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/ThemeToggle";
import {
  Calendar,
  Clock,
  Users,
  Bell,
  Shield,
  Presentation,
  GraduationCap,
  ArrowRight,
} from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="h-6 w-6 text-primary" />
            <span className="font-semibold text-lg">ClassTime</span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Link href="/login">
              <Button variant="outline" data-testid="button-login-nav">
                Login
              </Button>
            </Link>
            <a href="/api/login">
              <Button data-testid="button-admin-login">Admin Login</Button>
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl text-center">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Clock className="h-4 w-4" />
            Smart Timetable Management
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            Manage Your Class Schedules
            <br />
            <span className="text-primary">Effortlessly</span>
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto mb-10">
            A comprehensive timetable management system with role-based access for
            administrators, teachers, and students. Real-time notifications keep
            everyone in sync.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/login">
              <Button size="lg" data-testid="button-get-started">
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <a href="/api/login">
              <Button size="lg" variant="outline" data-testid="button-admin-access">
                Admin Access
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
            Powerful Features for Everyone
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {/* Admin Feature */}
            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Admin Control</h3>
                <p className="text-muted-foreground text-sm">
                  Full control over classrooms, classes, and user accounts.
                  Create and manage teacher and student credentials securely.
                </p>
                <ul className="mt-4 space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                    Manage classrooms & capacity
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                    Create user accounts
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                    Upload timetables
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Teacher Feature */}
            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="h-12 w-12 rounded-lg bg-chart-2/10 text-chart-2 flex items-center justify-center mb-4">
                  <Presentation className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Teacher Dashboard</h3>
                <p className="text-muted-foreground text-sm">
                  Schedule and manage your classes with ease. Assign rooms and
                  notify students of any changes instantly.
                </p>
                <ul className="mt-4 space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-chart-2" />
                    Schedule classes
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-chart-2" />
                    Assign room numbers
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-chart-2" />
                    Reschedule anytime
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Student Feature */}
            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="h-12 w-12 rounded-lg bg-chart-4/10 text-chart-4 flex items-center justify-center mb-4">
                  <GraduationCap className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Student View</h3>
                <p className="text-muted-foreground text-sm">
                  Stay updated with your class schedule. Receive real-time
                  notifications for any schedule changes.
                </p>
                <ul className="mt-4 space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-chart-4" />
                    View weekly timetable
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-chart-4" />
                    Real-time notifications
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-chart-4" />
                    Today's schedule
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
            How It Works
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4 font-bold">
                1
              </div>
              <h3 className="font-semibold mb-2">Admin Sets Up</h3>
              <p className="text-sm text-muted-foreground">
                Admin creates classes, classrooms, and user accounts for teachers
                and students
              </p>
            </div>
            <div className="text-center">
              <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4 font-bold">
                2
              </div>
              <h3 className="font-semibold mb-2">Teachers Schedule</h3>
              <p className="text-sm text-muted-foreground">
                Teachers log in and create schedules, assigning subjects and rooms
              </p>
            </div>
            <div className="text-center">
              <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4 font-bold">
                3
              </div>
              <h3 className="font-semibold mb-2">Students Get Notified</h3>
              <p className="text-sm text-muted-foreground">
                Students receive real-time notifications and view their timetables
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              <span className="font-semibold">ClassTime</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Class Timetable Management System - Role-Based Access Control
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
