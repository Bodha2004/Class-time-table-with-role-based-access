import { useQuery } from "@tanstack/react-query";
import { Calendar, Clock, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TimetableGrid } from "@/components/TimetableGrid";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { EmptyState } from "@/components/EmptyState";
import { useAuth } from "@/hooks/useAuth";
import { useState } from "react";
import type { ScheduleWithDetails, Class } from "@shared/schema";

export default function TimetablePage() {
  const { user } = useAuth();
  const isTeacher = user?.role === "teacher";
  const isStudent = user?.role === "student";
  const [selectedClassId, setSelectedClassId] = useState<string>("all");

  const { data: schedules = [], isLoading } = useQuery<ScheduleWithDetails[]>({
    queryKey: ["/api/schedules", selectedClassId],
    queryFn: async () => {
      const url = selectedClassId && selectedClassId !== "all"
        ? `/api/schedules?classId=${selectedClassId}`
        : "/api/schedules";
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch schedules");
      return res.json();
    },
  });

  const { data: classes = [] } = useQuery<Class[]>({
    queryKey: ["/api/classes"],
  });

  // For teachers, filter to only their schedules
  const filteredSchedules = isTeacher
    ? schedules.filter((s) => s.teacherId === user?.id)
    : schedules;

  if (isLoading) {
    return <LoadingSpinner text="Loading timetable..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isTeacher
              ? "My Timetable"
              : isStudent
              ? "Class Timetable"
              : "Timetable View"}
          </h1>
          <p className="text-muted-foreground">
            {isTeacher
              ? "Your weekly class schedule"
              : isStudent
              ? "View your weekly class schedule"
              : "View schedules by class"}
          </p>
        </div>
        {!isStudent && !isTeacher && (
          <Select value={selectedClassId} onValueChange={setSelectedClassId}>
            <SelectTrigger className="w-[200px]" data-testid="select-class-filter">
              <SelectValue placeholder="Select class" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Classes</SelectItem>
              {classes.map((cls) => (
                <SelectItem key={cls.id} value={cls.id}>
                  {cls.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Legend */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-sm font-medium text-muted-foreground">Legend:</span>
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 rounded bg-primary/10 border border-primary/50" />
              <span className="text-sm">Current Time Slot</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-4 w-1 rounded-full bg-primary" />
              <span className="text-sm">Subject Color Indicator</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timetable Grid */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Weekly Schedule
          </CardTitle>
          <Badge variant="outline">
            {filteredSchedules.length} classes scheduled
          </Badge>
        </CardHeader>
        <CardContent>
          {filteredSchedules.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="No schedules found"
              description={
                selectedClassId !== "all"
                  ? "No classes scheduled for this selection"
                  : "No classes have been scheduled yet"
              }
            />
          ) : (
            <TimetableGrid
              schedules={filteredSchedules}
              showTeacher={!isTeacher}
              highlightCurrent={true}
            />
          )}
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid gap-4 grid-cols-2 sm:grid-cols-4">
        {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].slice(0, 4).map((day) => {
          const daySchedules = filteredSchedules.filter(
            (s) => s.dayOfWeek === day.toLowerCase()
          );
          return (
            <Card key={day} className="hover-elevate">
              <CardContent className="p-4 text-center">
                <p className="text-sm text-muted-foreground mb-1">{day}</p>
                <p className="text-2xl font-bold">{daySchedules.length}</p>
                <p className="text-xs text-muted-foreground">classes</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
