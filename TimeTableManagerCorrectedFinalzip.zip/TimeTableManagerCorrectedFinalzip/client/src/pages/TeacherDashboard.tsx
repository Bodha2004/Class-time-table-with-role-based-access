import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  Clock,
  Calendar,
  MapPin,
  Plus,
  ChevronRight,
  Users,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatsCard } from "@/components/StatsCard";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { EmptyState } from "@/components/EmptyState";
import { format, isToday, parseISO, isBefore, isAfter } from "date-fns";
import type { ScheduleWithDetails } from "@shared/schema";

interface TeacherStats {
  totalSchedules: number;
  todayClasses: number;
  upcomingClasses: ScheduleWithDetails[];
}

export default function TeacherDashboard() {
  const { data: stats, isLoading } = useQuery<TeacherStats>({
    queryKey: ["/api/teacher/stats"],
  });

  const today = new Date().toLocaleDateString("en-US", { weekday: "long" }).toLowerCase();
  const currentTime = format(new Date(), "HH:mm");

  const todaysClasses = stats?.upcomingClasses?.filter(
    (s) => s.dayOfWeek === today
  ) || [];

  const sortedTodaysClasses = [...todaysClasses].sort((a, b) => {
    return (a.startTime || "").localeCompare(b.startTime || "");
  });

  if (isLoading) {
    return <LoadingSpinner text="Loading dashboard..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Teacher Dashboard</h1>
          <p className="text-muted-foreground">
            Manage your classes and schedules
          </p>
        </div>
        <Link href="/schedules">
          <Button className="gap-2" data-testid="button-schedule-class">
            <Plus className="h-4 w-4" />
            Schedule Class
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        <StatsCard
          title="Today's Classes"
          value={stats?.todayClasses || 0}
          icon={Calendar}
          color="primary"
          description="Classes scheduled for today"
        />
        <StatsCard
          title="Total Schedules"
          value={stats?.totalSchedules || 0}
          icon={Clock}
          color="chart-2"
          description="Active class schedules"
        />
        <StatsCard
          title="Classes This Week"
          value={stats?.upcomingClasses?.length || 0}
          icon={Users}
          color="chart-4"
          description="Upcoming this week"
        />
      </div>

      {/* Today's Schedule */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Today's Schedule
          </CardTitle>
          <Link href="/timetable">
            <Button variant="ghost" size="sm" className="gap-1" data-testid="button-view-timetable">
              View Full Timetable
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {sortedTodaysClasses.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="No classes today"
              description="You don't have any classes scheduled for today"
            />
          ) : (
            <div className="space-y-3">
              {sortedTodaysClasses.map((schedule) => {
                const isPast = schedule.endTime && schedule.endTime < currentTime;
                const isCurrent =
                  schedule.startTime &&
                  schedule.endTime &&
                  schedule.startTime <= currentTime &&
                  schedule.endTime >= currentTime;

                return (
                  <div
                    key={schedule.id}
                    className={`flex items-center gap-4 p-4 rounded-lg border ${
                      isCurrent
                        ? "border-primary bg-primary/5"
                        : isPast
                        ? "opacity-60"
                        : "hover-elevate"
                    }`}
                    data-testid={`schedule-item-${schedule.id}`}
                  >
                    {/* Time Block */}
                    <div className="text-center min-w-[80px]">
                      <p className="text-lg font-bold">
                        {schedule.startTime?.slice(0, 5)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        to {schedule.endTime?.slice(0, 5)}
                      </p>
                    </div>

                    {/* Divider */}
                    <div
                      className="w-1 h-12 rounded-full"
                      style={{ backgroundColor: schedule.subject?.color || "#3B82F6" }}
                    />

                    {/* Class Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold">{schedule.subject?.name}</p>
                        {isCurrent && (
                          <Badge variant="default" className="text-xs">
                            In Progress
                          </Badge>
                        )}
                        {isPast && (
                          <Badge variant="secondary" className="text-xs">
                            Completed
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {schedule.classroom?.name}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          {schedule.class?.name}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <Link href="/schedules">
                      <Button variant="ghost" size="sm" data-testid={`button-edit-${schedule.id}`}>
                        Edit
                      </Button>
                    </Link>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
            <CardTitle className="text-base font-semibold">Schedule Management</CardTitle>
            <Clock className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Create, edit, or reschedule your classes with room assignments
            </p>
            <Link href="/schedules">
              <Button variant="outline" className="w-full" data-testid="button-manage-schedules">
                Manage Schedules
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
            <CardTitle className="text-base font-semibold">Weekly Timetable</CardTitle>
            <Calendar className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              View your complete weekly schedule at a glance
            </p>
            <Link href="/timetable">
              <Button variant="outline" className="w-full" data-testid="button-view-weekly">
                View Timetable
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
