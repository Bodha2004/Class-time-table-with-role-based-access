import { useQuery } from "@tanstack/react-query";
import {
  Users,
  Building2,
  GraduationCap,
  Clock,
  Presentation,
  TrendingUp,
  Calendar,
  Plus,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatsCard } from "@/components/StatsCard";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { EmptyState } from "@/components/EmptyState";
import { Link } from "wouter";
import type { User, Classroom, Class, Schedule } from "@shared/schema";

interface DashboardStats {
  totalTeachers: number;
  totalStudents: number;
  totalClassrooms: number;
  totalClasses: number;
  totalSchedules: number;
  recentUsers: User[];
}

export default function AdminDashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/stats"],
  });

  if (isLoading) {
    return <LoadingSpinner text="Loading dashboard..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Manage your timetable system and user accounts
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/users">
            <Button className="gap-2" data-testid="button-add-user">
              <Plus className="h-4 w-4" />
              Add User
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Teachers"
          value={stats?.totalTeachers || 0}
          icon={Presentation}
          color="chart-2"
          description="Active teachers"
        />
        <StatsCard
          title="Students"
          value={stats?.totalStudents || 0}
          icon={GraduationCap}
          color="chart-4"
          description="Enrolled students"
        />
        <StatsCard
          title="Classrooms"
          value={stats?.totalClassrooms || 0}
          icon={Building2}
          color="primary"
          description="Available rooms"
        />
        <StatsCard
          title="Classes"
          value={stats?.totalClasses || 0}
          icon={Users}
          color="chart-2"
          description="Active classes"
        />
      </div>

      {/* Quick Actions */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
            <CardTitle className="text-base font-semibold">User Management</CardTitle>
            <Users className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Create accounts for teachers and students with secure credentials
            </p>
            <Link href="/users">
              <Button variant="outline" className="w-full" data-testid="button-manage-users">
                Manage Users
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
            <CardTitle className="text-base font-semibold">Classroom Setup</CardTitle>
            <Building2 className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Add and configure classrooms with capacity and facilities
            </p>
            <Link href="/classrooms">
              <Button variant="outline" className="w-full" data-testid="button-manage-classrooms">
                Manage Classrooms
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
            <CardTitle className="text-base font-semibold">Class Management</CardTitle>
            <GraduationCap className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Create and organize classes with sections and academic years
            </p>
            <Link href="/classes">
              <Button variant="outline" className="w-full" data-testid="button-manage-classes">
                Manage Classes
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Recent Users */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle>Recent Users</CardTitle>
          <Link href="/users">
            <Button variant="ghost" size="sm" data-testid="button-view-all-users">
              View All
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {!stats?.recentUsers || stats.recentUsers.length === 0 ? (
            <EmptyState
              icon={Users}
              title="No users yet"
              description="Start by creating teacher and student accounts"
              action={{
                label: "Add User",
                onClick: () => (window.location.href = "/users"),
              }}
            />
          ) : (
            <div className="space-y-3">
              {stats.recentUsers.slice(0, 5).map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover-elevate"
                  data-testid={`user-row-${user.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-medium text-primary">
                        {user.firstName?.[0] || user.username?.[0] || "U"}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-sm">
                        {user.firstName
                          ? `${user.firstName} ${user.lastName || ""}`
                          : user.username}
                      </p>
                      <p className="text-xs text-muted-foreground">@{user.username}</p>
                    </div>
                  </div>
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      user.role === "teacher"
                        ? "bg-chart-2/10 text-chart-2"
                        : "bg-chart-4/10 text-chart-4"
                    }`}
                  >
                    {user.role}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
