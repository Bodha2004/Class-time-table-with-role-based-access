import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Plus,
  Search,
  MoreVertical,
  Trash2,
  Edit,
  Building2,
  Users,
  Check,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { EmptyState } from "@/components/EmptyState";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertClassroomSchema, type InsertClassroom, type Classroom } from "@shared/schema";

export default function ClassroomsPage() {
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editClassroom, setEditClassroom] = useState<Classroom | null>(null);
  const [deleteClassroomId, setDeleteClassroomId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: classrooms = [], isLoading } = useQuery<Classroom[]>({
    queryKey: ["/api/classrooms"],
  });

  const form = useForm<InsertClassroom>({
    resolver: zodResolver(insertClassroomSchema),
    defaultValues: {
      name: "",
      building: "",
      capacity: undefined,
      facilities: "",
      isActive: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertClassroom) => {
      return apiRequest("POST", "/api/classrooms", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classrooms"] });
      toast({
        title: "Classroom created",
        description: "The classroom has been added successfully",
      });
      setIsCreateOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create classroom",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: InsertClassroom }) => {
      return apiRequest("PATCH", `/api/classrooms/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classrooms"] });
      toast({
        title: "Classroom updated",
        description: "The classroom has been updated successfully",
      });
      setEditClassroom(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update classroom",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/classrooms/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classrooms"] });
      toast({
        title: "Classroom deleted",
        description: "The classroom has been removed",
      });
      setDeleteClassroomId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete classroom",
        variant: "destructive",
      });
    },
  });

  const filteredClassrooms = classrooms.filter((classroom) =>
    classroom.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    classroom.building?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openEditDialog = (classroom: Classroom) => {
    form.reset({
      name: classroom.name,
      building: classroom.building || "",
      capacity: classroom.capacity || undefined,
      facilities: classroom.facilities || "",
      isActive: classroom.isActive ?? true,
    });
    setEditClassroom(classroom);
  };

  if (isLoading) {
    return <LoadingSpinner text="Loading classrooms..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Classrooms</h1>
          <p className="text-muted-foreground">
            Manage your classroom spaces and facilities
          </p>
        </div>
        <Button
          className="gap-2"
          onClick={() => {
            form.reset();
            setIsCreateOpen(true);
          }}
          data-testid="button-add-classroom"
        >
          <Plus className="h-4 w-4" />
          Add Classroom
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search classrooms..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
          data-testid="input-search-classrooms"
        />
      </div>

      {/* Classrooms Grid */}
      {filteredClassrooms.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No classrooms found"
          description={
            searchQuery
              ? "Try adjusting your search"
              : "Add your first classroom to get started"
          }
          action={
            !searchQuery
              ? {
                  label: "Add Classroom",
                  onClick: () => setIsCreateOpen(true),
                }
              : undefined
          }
        />
      ) : (
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {filteredClassrooms.map((classroom) => (
            <Card key={classroom.id} className="hover-elevate" data-testid={`classroom-card-${classroom.id}`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Building2 className="h-6 w-6 text-primary" />
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" data-testid={`button-classroom-menu-${classroom.id}`}>
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openEditDialog(classroom)} data-testid={`button-edit-${classroom.id}`}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => setDeleteClassroomId(classroom.id)}
                        className="text-destructive"
                        data-testid={`button-delete-${classroom.id}`}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <h3 className="font-semibold text-lg mb-1">{classroom.name}</h3>
                {classroom.building && (
                  <p className="text-sm text-muted-foreground mb-3">
                    {classroom.building}
                  </p>
                )}

                <div className="flex flex-wrap gap-2 mb-3">
                  {classroom.capacity && (
                    <Badge variant="secondary" className="gap-1">
                      <Users className="h-3 w-3" />
                      {classroom.capacity} seats
                    </Badge>
                  )}
                  <Badge variant={classroom.isActive ? "default" : "secondary"}>
                    {classroom.isActive ? (
                      <>
                        <Check className="h-3 w-3 mr-1" />
                        Active
                      </>
                    ) : (
                      <>
                        <X className="h-3 w-3 mr-1" />
                        Inactive
                      </>
                    )}
                  </Badge>
                </div>

                {classroom.facilities && (
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {classroom.facilities}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog
        open={isCreateOpen || !!editClassroom}
        onOpenChange={(open) => {
          if (!open) {
            setIsCreateOpen(false);
            setEditClassroom(null);
            form.reset();
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editClassroom ? "Edit Classroom" : "Add Classroom"}
            </DialogTitle>
            <DialogDescription>
              {editClassroom
                ? "Update the classroom details"
                : "Add a new classroom to your institution"}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit((data) =>
                editClassroom
                  ? updateMutation.mutate({ id: editClassroom.id, data })
                  : createMutation.mutate(data)
              )}
              className="space-y-4"
            >
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Room Name / Number</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Room 101" {...field} data-testid="input-room-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="building"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Building (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g., Main Building"
                        {...field}
                        value={field.value || ""}
                        data-testid="input-building"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="capacity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Capacity (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="e.g., 30"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) =>
                          field.onChange(e.target.value ? parseInt(e.target.value) : undefined)
                        }
                        data-testid="input-capacity"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="facilities"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Facilities (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="e.g., Projector, Whiteboard, AC, Computer Lab"
                        {...field}
                        value={field.value || ""}
                        data-testid="input-facilities"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsCreateOpen(false);
                    setEditClassroom(null);
                  }}
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-save"
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Saving..."
                    : editClassroom
                    ? "Update"
                    : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteClassroomId} onOpenChange={() => setDeleteClassroomId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Classroom</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this classroom? This will also remove all
              associated schedules.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteClassroomId(null)} data-testid="button-cancel-delete">
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteClassroomId && deleteMutation.mutate(deleteClassroomId)}
              disabled={deleteMutation.isPending}
              data-testid="button-confirm-delete"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
