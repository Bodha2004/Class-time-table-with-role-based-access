import { Shield, Presentation, GraduationCap } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface RoleBadgeProps {
  role: "admin" | "teacher" | "student";
  size?: "sm" | "default";
}

const roleConfig = {
  admin: {
    icon: Shield,
    label: "Admin",
    className: "bg-primary/10 text-primary border-primary/20",
  },
  teacher: {
    icon: Presentation,
    label: "Teacher",
    className: "bg-chart-2/10 text-chart-2 border-chart-2/20",
  },
  student: {
    icon: GraduationCap,
    label: "Student",
    className: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  },
};

export function RoleBadge({ role, size = "default" }: RoleBadgeProps) {
  const config = roleConfig[role];
  const Icon = config.icon;

  return (
    <Badge
      variant="outline"
      className={`${config.className} ${size === "sm" ? "text-xs px-2 py-0.5" : ""}`}
      data-testid={`badge-role-${role}`}
    >
      <Icon className={`${size === "sm" ? "h-3 w-3" : "h-4 w-4"} mr-1`} />
      {config.label}
    </Badge>
  );
}
