import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, User } from "lucide-react";
import type { ScheduleWithDetails } from "@shared/schema";

interface TimetableGridProps {
  schedules: ScheduleWithDetails[];
  onScheduleClick?: (schedule: ScheduleWithDetails) => void;
  showTeacher?: boolean;
  highlightCurrent?: boolean;
}

const DAYS = [
  { key: "monday", label: "Mon" },
  { key: "tuesday", label: "Tue" },
  { key: "wednesday", label: "Wed" },
  { key: "thursday", label: "Thu" },
  { key: "friday", label: "Fri" },
  { key: "saturday", label: "Sat" },
] as const;

const TIME_SLOTS = [
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
];

export function TimetableGrid({
  schedules,
  onScheduleClick,
  showTeacher = true,
  highlightCurrent = true,
}: TimetableGridProps) {
  const currentDay = new Date().toLocaleDateString("en-US", { weekday: "long" }).toLowerCase();
  const currentTime = new Date().toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });

  const scheduleMap = useMemo(() => {
    const map = new Map<string, ScheduleWithDetails[]>();
    schedules.forEach((schedule) => {
      const key = `${schedule.dayOfWeek}-${schedule.startTime?.slice(0, 5)}`;
      const existing = map.get(key) || [];
      map.set(key, [...existing, schedule]);
    });
    return map;
  }, [schedules]);

  const isCurrentSlot = (day: string, time: string) => {
    if (!highlightCurrent) return false;
    if (day !== currentDay) return false;
    const slotHour = parseInt(time.split(":")[0]);
    const currentHour = parseInt(currentTime.split(":")[0]);
    return slotHour === currentHour;
  };

  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[800px]">
        {/* Header Row */}
        <div className="grid grid-cols-7 gap-1 mb-1">
          <div className="p-2 text-center text-sm font-medium text-muted-foreground">
            Time
          </div>
          {DAYS.map((day) => (
            <div
              key={day.key}
              className={`p-2 text-center text-sm font-medium ${
                day.key === currentDay
                  ? "text-primary bg-primary/5 rounded-md"
                  : "text-muted-foreground"
              }`}
            >
              {day.label}
            </div>
          ))}
        </div>

        {/* Time Rows */}
        {TIME_SLOTS.map((time) => (
          <div key={time} className="grid grid-cols-7 gap-1 mb-1">
            {/* Time Label */}
            <div className="p-2 text-sm text-muted-foreground text-center flex items-center justify-center">
              {time}
            </div>

            {/* Day Cells */}
            {DAYS.map((day) => {
              const slotSchedules = scheduleMap.get(`${day.key}-${time}`) || [];
              const isCurrent = isCurrentSlot(day.key, time);

              return (
                <div
                  key={`${day.key}-${time}`}
                  className={`min-h-[80px] rounded-md border p-1 ${
                    isCurrent
                      ? "border-primary/50 bg-primary/5"
                      : "border-border bg-card/50"
                  } ${slotSchedules.length === 0 ? "opacity-60" : ""}`}
                  data-testid={`slot-${day.key}-${time}`}
                >
                  {slotSchedules.map((schedule) => (
                    <Card
                      key={schedule.id}
                      className={`p-2 mb-1 cursor-pointer hover-elevate border-l-4 ${
                        onScheduleClick ? "cursor-pointer" : ""
                      }`}
                      style={{ borderLeftColor: schedule.subject?.color || "#3B82F6" }}
                      onClick={() => onScheduleClick?.(schedule)}
                      data-testid={`schedule-card-${schedule.id}`}
                    >
                      <div className="space-y-1">
                        <p className="font-medium text-xs truncate">
                          {schedule.subject?.name}
                        </p>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <MapPin className="h-3 w-3" />
                          <span className="truncate">{schedule.classroom?.name}</span>
                        </div>
                        {showTeacher && schedule.teacher && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <User className="h-3 w-3" />
                            <span className="truncate">
                              {schedule.teacher.firstName} {schedule.teacher.lastName}
                            </span>
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
