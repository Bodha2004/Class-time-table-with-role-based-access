import { Link, useLocation } from "wouter";
import {
  Calendar,
  LayoutDashboard,
  Users,
  Building2,
  BookOpen,
  Clock,
  Settings,
  LogOut,
  GraduationCap,
  Bell,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { UserAvatar } from "@/components/UserAvatar";
import { RoleBadge } from "@/components/RoleBadge";
import { Button } from "@/components/ui/button";
import type { User } from "@shared/schema";

interface AppSidebarProps {
  user: User | null | undefined;
}

export function AppSidebar({ user }: AppSidebarProps) {
  const [location] = useLocation();
  const role = user?.role || "student";

  const adminMenuItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/" },
    { icon: Users, label: "Users", path: "/users" },
    { icon: Building2, label: "Classrooms", path: "/classrooms" },
    { icon: GraduationCap, label: "Classes", path: "/classes" },
    { icon: BookOpen, label: "Subjects", path: "/subjects" },
    { icon: Clock, label: "Schedules", path: "/schedules" },
  ];

  const teacherMenuItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/" },
    { icon: Clock, label: "My Schedules", path: "/schedules" },
    { icon: Calendar, label: "Timetable", path: "/timetable" },
  ];

  const studentMenuItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/" },
    { icon: Calendar, label: "My Timetable", path: "/timetable" },
    { icon: Bell, label: "Notifications", path: "/notifications" },
  ];

  const menuItems =
    role === "admin"
      ? adminMenuItems
      : role === "teacher"
      ? teacherMenuItems
      : studentMenuItems;

  return (
    <Sidebar>
      <SidebarHeader className="border-b px-4 py-4">
        <div className="flex items-center gap-2">
          <Calendar className="h-6 w-6 text-primary" />
          <span className="font-semibold text-lg">ClassTime</span>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.path}
                    data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <Link href={item.path}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t p-4">
        <div className="flex items-center gap-3 mb-4">
          <UserAvatar user={user} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">
              {user?.firstName || user?.username || "User"}
              {user?.lastName ? ` ${user.lastName}` : ""}
            </p>
            <RoleBadge role={role as "admin" | "teacher" | "student"} size="sm" />
          </div>
        </div>
        <a href="/api/logout" className="block">
          <Button
            variant="outline"
            className="w-full justify-start gap-2"
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </a>
      </SidebarFooter>
    </Sidebar>
  );
}
